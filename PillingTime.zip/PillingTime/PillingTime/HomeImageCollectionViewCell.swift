//
//  HomeImageCollectionViewCell.swift
//  PillingTime
//
//  Created by Enirobot on 2018. 2. 3..
//  Copyright © 2018년 Enirobot. All rights reserved.
//

import UIKit

class HomeImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectionImageView: UIImageView!
}
