//
//  AddTitleTableViewCell.swift
//  PillingTime
//
//  Created by Enirobot on 2018. 2. 2..
//  Copyright © 2018년 Enirobot. All rights reserved.
//

import UIKit

class AddTitleTableViewCell: UITableViewCell {

    @IBOutlet weak var AddTitleLable: UILabel!
    @IBOutlet weak var AddTitleTextField: UITextField!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
